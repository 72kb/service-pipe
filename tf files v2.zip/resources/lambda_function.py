import boto3
import json
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Adding code to get the job ID from the event object and to initialize the CodePipeline client
    job_id = event["CodePipeline.job"]["id"]
    codepipeline = boto3.client('codepipeline')
    
    sc = boto3.client('servicecatalog')
    cc = boto3.client('codecommit')

    portfolio_name = 'My Portfolio'
    repository_name = 'MyRepo'

    try:
        commit_id = event['Records'][0]['codecommit']['references'][0]['commit']
        commit = cc.get_commit(repositoryName=repository_name, commitId=commit_id)
        files = commit['commit']['tree']['tree']
    except Exception as e:
        logger.error("Error getting commit details: %s", e)
        # Adding a failure report to CodePipeline in case this block fails
        codepipeline.put_job_failure_result(
            jobId=job_id,
            failureDetails={'message': str(e), 'type': 'JobFailed'}
        )
        raise

    for file in files:
        if not file['absolutePath'].endswith('.json'):
            continue

        product_name = os.path.splitext(file['absolutePath'])[0]

        try:
            blob = cc.get_blob(repositoryName=repository_name, blobId=file['blobId'])
            template = json.loads(blob['content'])
        except Exception as e:
            logger.error("Error getting file content: %s", e)
            # Adding a failure report to CodePipeline in case this block fails
            codepipeline.put_job_failure_result(
                jobId=job_id,
                failureDetails={'message': str(e), 'type': 'JobFailed'}
            )
            continue

        try:
            # Your service catalog code here
            # ...
        except Exception as e:
            logger.error("Error creating or updating portfolio/product: %s", e)
            # Adding a failure report to CodePipeline in case this block fails
            codepipeline.put_job_failure_result(
                jobId=job_id,
                failureDetails={'message': str(e), 'type': 'JobFailed'}
            )
            continue

    # Adding a success report to CodePipeline if all goes well
    codepipeline.put_job_success_result(jobId=job_id)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Lambda execution completed!')
    }
